# ICST Kristall Motion Map — Bundle

Version **2.1.5** | [Online User Guide](https://ambisonics.ch/icst-ambisonics-plugins/18_kristall_motion_map/)

A standalone REAPER Lua script that arranges up to 64 AmbiEncoder sources as
points in a 3D crystal lattice and moves them through space using a step
sequencer — with real-time GUI, OSC output, and 8 built-in presets.

---

## Included files

```
scripts/
  JS_ICST_Kristall_Motion_Map.lua    ← Main script (load this as ReaScript)

jsfx/
  JS_ICST_Kristall_Controller.jsfx   ← Optional MIDI/JSFX control surface

README.md                             ← This file
```

---

## Requirements

- **REAPER** v6 or later (v7 recommended)
- **ICST AmbiEncoder_64** on the target track
- **Python 3** with `python-osc` — only needed for live OSC preview

```bash
pip3 install python-osc
```

---

## Installation

### 1 — Load the main script

1. In REAPER: **Actions → Load ReaScript…**
2. Select `scripts/JS_ICST_Kristall_Motion_Map.lua` → **Open**
3. Run the action — the Kristall Motion Map window opens.

### 2 — Optional: JSFX controller (MIDI control)

1. Add `jsfx/JS_ICST_Kristall_Controller.jsfx` to any track's FX chain
   (drag & drop, or via the FX browser after copying to your REAPER JSFX folder).
2. Map MIDI CCs to the sliders via REAPER's FX parameter lane or MIDI Learn.
3. The Kristall script detects the JSFX automatically and reads its parameters
   every frame — no further setup needed.

| JSFX Slider | Function |
|-------------|----------|
| slider1 | Preset Trigger (1–8) |
| slider2 | Global Rate |
| slider3 | Rate Mode (steps/sec or BPM) |
| slider4 | Smoothing on/off |
| slider5 | Glide Time (sec) |
| slider6 | Global Pitch — tilt fwd/bck (−180…+180°) |
| slider7 | Global Yaw — spin L/R (−180…+180°) |
| slider8 | Global Roll — rotate CW/CCW (−180…+180°) |

### 3 — Connect OSC

1. Enter your AmbiEncoder host IP and port in the Kristall GUI (Row 1).
2. Click **Connect** — the status dot turns green.
3. The incoming rotation port (`output port + 1`, e.g., `9002`) is shown
   as **in: 9002** — send OSC to that port to control Pitch/Yaw/Roll
   from TouchOSC, Max/MSP, or any OSC tool.

---

## Built-in presets

| # | Name | Description |
|---|------|-------------|
| 1 | Cubic | 8 corners of a unit cube |
| 2 | Tetragonal | Equal XY, different Z spacing |
| 3 | Hexagonal | 2D hex ring tiled along Z |
| 4 | Rnd.Swarm | 20 random instances in a sphere |
| 5 | Orthorhombic | Three unequal orthogonal axes (α=β=γ=90°) |
| 6 | Rhombohedral | Equal axes, equal non-orthogonal angles (α=β=γ≠90°) |
| 7 | Monoclinic | One inclined axis (α=γ=90°, β≠90°) |
| 8 | Triclinic | No equal axes, no right angles |

---

## Changelog

### v2.1.5
- **Fix: Windows console popup + first-connect failure** — replaced `python3 || python` with `pythonw || python` on Windows. `pythonw.exe` is the windowless Python launcher (no cmd.exe popup). `python3` is skipped entirely on Windows because it either doesn't exist or triggers the MS Store Python stub (exit code 9009), which leaves the stdin pipe detached for the `||` fallback — causing the first Connect to silently fail while the second succeeds.

### v2.1.4
- **Fix: Receiver thread robustness (Windows)** — if both `os.replace` and the direct-write fallback fail (extreme Windows lock scenario), the outer `except: break` would silently kill the OSC receiver thread. The direct-write fallback is now wrapped in its own `try/except: pass` so transient write errors are ignored and the thread continues.
- **Fix: `oscDisconnect` crash on Windows** — `os.remove(osc.state_file)` was called without `pcall`; if the file didn't exist (race condition or was already cleaned up), it threw a Lua error. Wrapped with `pcall(os.remove, ...)`.

### v2.1.3
- **Fix: Windows OSC compatibility** — three Windows-specific bugs fixed:
  1. `os.tmpname()` returned unwritable root-relative paths on Windows; replaced with `%TEMP%`-based helper.
  2. `2>/dev/null` (Unix shell) replaced with `2>nul` on Windows; paths are now quoted to handle spaces.
  3. `os.replace()` in the Python bridge raised `PermissionError` on Windows when Lua had the state file open; replaced with an atomic-replace-then-direct-write fallback.

### v2.1.2
- **Fix: Interaction fields now editable** — Send / Receive / Radius fields in the Interaction section were unresponsive to clicks when scrolled into view. Root cause: items rendered below the param-panel viewport were painted over the status bar; clicks in that area triggered the status-bar handler which stole focus. Fixed with a viewport clip guard that prevents drawing and hit-test registration outside the visible scroll area.

### v2.1.1
- **Global Zoom** slider (Row 4, `×` scrubber) — scales the entire crystal figure around the origin (0 = collapse, 1 = neutral, 2 = 2×). Zoom is applied to the OSC preview and the lattice preview in real time.
- **Global Ping-Pong** (`⇄ PP` button, Row 2) — all instances reverse direction simultaneously so the whole crystal figure bounces as one unit.
- **Click-to-edit** on Row 3 / Row 4 scrubbers — a short click (< 4 px drag) opens a numeric text field; press Enter to confirm.

### v0.2.0
- Pause / Stop buttons
- Global Pos (Offset X/Y/Z) and Move (direction X/Y/Z) sliders (Row 3)
- Global Rotation Pt / Yw / Rl sliders (Row 4)
- Preset bar (8 quick-select buttons)

### v0.1.0
- Initial release

---

## Full documentation

→ [ambisonics.ch — ICST Kristall Motion Map User Guide](https://ambisonics.ch/icst-ambisonics-plugins/18_kristall_motion_map/)
