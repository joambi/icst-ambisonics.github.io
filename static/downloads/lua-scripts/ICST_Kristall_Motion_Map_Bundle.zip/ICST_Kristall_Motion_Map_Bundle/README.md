# ICST Kristall Motion Map — Bundle

Version **0.2.0** | [Online User Guide](https://ambisonics.ch/icst-ambisonics-plugins/18_kristall_motion_map/)

A standalone REAPER Lua script that arranges up to 64 AmbiEncoder sources as
points in a 3D crystal lattice and moves them through space using a step
sequencer — with real-time GUI, OSC output, and 8 built-in presets.

---

## Included files

```
scripts/
  JS_ICST_Kristall_Motion_Map.lua    ← Main script (load this as ReaScript)

jsfx/
  JS_ICST_Kristall_Controller.jsfx   ← Optional MIDI/JSFX control surface

README.md                             ← This file
```

---

## Requirements

- **REAPER** v6 or later (v7 recommended)
- **ICST AmbiEncoder_64** on the target track
- **Python 3** with `python-osc` — only needed for live OSC preview

```bash
pip3 install python-osc
```

---

## Installation

### 1 — Load the main script

1. In REAPER: **Actions → Load ReaScript…**
2. Select `scripts/JS_ICST_Kristall_Motion_Map.lua` → **Open**
3. Run the action — the Kristall Motion Map window opens.

### 2 — Optional: JSFX controller (MIDI control)

1. Add `jsfx/JS_ICST_Kristall_Controller.jsfx` to any track's FX chain
   (drag & drop, or via the FX browser after copying to your REAPER JSFX folder).
2. Map MIDI CCs to the sliders via REAPER's FX parameter lane or MIDI Learn.
3. The Kristall script detects the JSFX automatically and reads its parameters
   every frame — no further setup needed.

| JSFX Slider | Function |
|-------------|----------|
| slider1 | Preset Trigger (1–8) |
| slider2 | Global Rate |
| slider3 | Rate Mode (steps/sec or BPM) |
| slider4 | Smoothing on/off |
| slider5 | Glide Time (sec) |
| slider6 | Global Pitch — tilt fwd/bck (−180…+180°) |
| slider7 | Global Yaw — spin L/R (−180…+180°) |
| slider8 | Global Roll — rotate CW/CCW (−180…+180°) |

### 3 — Connect OSC

1. Enter your AmbiEncoder host IP and port in the Kristall GUI (Row 1).
2. Click **Connect** — the status dot turns green.
3. The incoming rotation port (`output port + 1`, e.g., `9002`) is shown
   as **in: 9002** — send OSC to that port to control Pitch/Yaw/Roll
   from TouchOSC, Max/MSP, or any OSC tool.

---

## Built-in presets

| # | Name | Description |
|---|------|-------------|
| 1 | Cubic | 8 corners of a unit cube |
| 2 | Tetragonal | Equal XY, different Z spacing |
| 3 | Hexagonal | 2D hex ring tiled along Z |
| 4 | Rnd.Swarm | 20 random instances in a sphere |
| 5 | Orthorhombic | Three unequal orthogonal axes (α=β=γ=90°) |
| 6 | Rhombohedral | Equal axes, equal non-orthogonal angles (α=β=γ≠90°) |
| 7 | Monoclinic | One inclined axis (α=γ=90°, β≠90°) |
| 8 | Triclinic | No equal axes, no right angles |

---

## Full documentation

→ [ambisonics.ch — ICST Kristall Motion Map User Guide](https://ambisonics.ch/icst-ambisonics-plugins/18_kristall_motion_map/)
