ICST Ambi Motion Map Bundle - v2.4.4
=====================================
EN: Keep both Lua files in the SAME folder. In REAPER: Actions > Load ReaScript... > JS_AmbiEncoder64_Motion_Map_GUI.lua
    (the GUI finds the writer script automatically). Select one track with ICST AmbiEncoder_64 and set a time selection.
    Python 3 is needed only for the live OSC preview. Docs: https://ambisonics.ch/icst-ambisonics-plugins/15_icst_ambi_motion_map/
DE: Beide Lua-Dateien im SELBEN Ordner lassen. In REAPER: Actions > Load ReaScript... > JS_AmbiEncoder64_Motion_Map_GUI.lua
    (das GUI findet das Writer-Script automatisch). Einen Track mit ICST AmbiEncoder_64 waehlen und eine Time Selection setzen.
    Python 3 wird nur fuer die Live-OSC-Vorschau benoetigt. Doku: https://ambisonics.ch/de/icst-ambisonics-plugins/15_icst_ambi_motion_map/
Contents / Inhalt: JS_AmbiEncoder64_Motion_Map_GUI.lua (v2.4.4), JS_Write_AmbiEncoder64_Spat_Motion_Automation.lua
Licence / Lizenz: GPL3, ICST ZHdK
