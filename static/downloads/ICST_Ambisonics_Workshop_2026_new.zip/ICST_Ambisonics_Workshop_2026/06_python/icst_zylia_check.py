#!/usr/bin/env python3
"""
ICST Ambisonics Workshop 2026 — Zylia Recording Checker
=========================================================
Verifies that a Zylia ZM-1 recording is correctly exported:
  - 19 channels (A-Format raw capsules)
  - 48000 Hz sample rate
  - 24-bit PCM

Run BEFORE importing into Reaper for A→B conversion.

Requires:  pip install soundfile

Usage:
    python icst_zylia_check.py path/to/zylia_recording.wav
"""

import sys
import os

try:
    import soundfile as sf
except ImportError:
    sys.exit("Please install soundfile first:  pip install soundfile")

EXPECTED_CH   = 19
EXPECTED_RATE = 48000
EXPECTED_BIT  = "PCM_24"


def check(path: str) -> bool:
    print(f"\nChecking: {os.path.basename(path)}")
    print("-" * 40)

    if not os.path.isfile(path):
        print(f"  ERROR: File not found: {path}")
        return False

    try:
        info = sf.info(path)
    except Exception as e:
        print(f"  ERROR: Cannot read file: {e}")
        return False

    ok = True

    # Channels
    status = "OK" if info.channels == EXPECTED_CH else "FAIL"
    if status == "FAIL":
        ok = False
    print(f"  Channels    : {info.channels:>3}  (expected {EXPECTED_CH})  [{status}]")

    # Sample rate
    status = "OK" if info.samplerate == EXPECTED_RATE else "WARN"
    print(f"  Sample rate : {info.samplerate} Hz  (expected {EXPECTED_RATE})  [{status}]")

    # Bit depth
    status = "OK" if info.subtype == EXPECTED_BIT else "WARN"
    print(f"  Bit depth   : {info.subtype}  (expected {EXPECTED_BIT})  [{status}]")

    # Duration
    mins, secs = divmod(info.duration, 60)
    size_mb = os.path.getsize(path) / (1024 * 1024)
    print(f"  Duration    : {int(mins):02d}:{secs:05.2f}")
    print(f"  File size   : {size_mb:.1f} MB")

    print()
    if ok:
        print("  RESULT: Ready for A->B conversion in Reaper!")
    else:
        print("  RESULT: Check failed — see issues above.")
        print("  Tip: Re-export from the Zylia App with 'Ambisonic' output disabled")
        print("       to get the raw 19-channel A-Format WAV.")
    return ok


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(0)
    for f in sys.argv[1:]:
        check(f)
    print()
