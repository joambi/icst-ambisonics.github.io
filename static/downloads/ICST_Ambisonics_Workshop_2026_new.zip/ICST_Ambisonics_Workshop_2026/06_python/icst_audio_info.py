#!/usr/bin/env python3
"""
ICST Ambisonics Workshop 2026 — Audio File Inspector
=====================================================
Prints channel count, sample rate, bit depth and duration
for any audio file(s) you point it at.

Requires:  pip install soundfile

Usage:
    python icst_audio_info.py path/to/file.wav
    python icst_audio_info.py path/to/folder/
"""

import sys
import os

try:
    import soundfile as sf
except ImportError:
    sys.exit("Please install soundfile first:  pip install soundfile")


CHANNEL_LABELS = {
    1:  "Mono",
    2:  "Stereo",
    4:  "FOA (B-Format, 1st order)",
    9:  "HOA 2nd order",
    16: "HOA 3rd order (Zylia ZM-1 output)",
    19: "A-Format (Zylia ZM-1 raw capsules)",
    25: "HOA 4th order",
}


def describe(path: str) -> None:
    try:
        info = sf.info(path)
    except Exception as e:
        print(f"  ERROR: {e}")
        return

    ch_label = CHANNEL_LABELS.get(info.channels, f"{info.channels}ch")
    mins, secs = divmod(info.duration, 60)
    size_mb = os.path.getsize(path) / (1024 * 1024)

    print(f"\n  File    : {os.path.basename(path)}")
    print(f"  Format  : {info.format} / {info.subtype}")
    print(f"  Channels: {info.channels}  →  {ch_label}")
    print(f"  Rate    : {info.samplerate} Hz")
    print(f"  Duration: {int(mins):02d}:{secs:05.2f}")
    print(f"  Size    : {size_mb:.2f} MB")
    print(f"  Frames  : {info.frames:,}")


def scan(path: str) -> None:
    if os.path.isfile(path):
        describe(path)
    elif os.path.isdir(path):
        found = False
        for root, _, files in os.walk(path):
            for f in sorted(files):
                if f.lower().endswith((".wav", ".aiff", ".aif", ".flac", ".ogg", ".w64")):
                    found = True
                    describe(os.path.join(root, f))
        if not found:
            print("No audio files found.")
    else:
        print(f"Not found: {path}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(0)
    print("=" * 56)
    print("  ICST Ambisonics — Audio File Inspector")
    print("=" * 56)
    for arg in sys.argv[1:]:
        scan(arg)
    print()
