# ICST Ambisonics Workshop 2026
### Institute for Computer Music and Sound Technology (ICST) — ZHdK

**Working with Ambisonics: HOA Recording, Encoding, Processing & Decoding**

---

## What's in this package

```
ICST_Ambisonics_Workshop_2026/
│
├── README.md                        ← You are here
│
├── 01_reaper-sessions/              ← Reaper projects + audio
│   ├── zylia_recording_example.RPP  ← A-Format → B-Format recording chain
│   ├── spatial_counterpoint_workshop.RPP  ← Encoding / FX / Decoding exercise
│   ├── automation_plan.csv          ← Reference for spatial automation exercise
│   └── audio/                       ← Dry source files for the exercise
│       ├── 01_percussion_impulses_mono.wav
│       ├── 02_depth_drone_mono.wav
│       └── 03_counterpoint_melody_mono.wav
│
├── 02_lua-scripts/                  ← Reaper ReaScripts
│   ├── icst_ambi_kopter.lua         ← Physics-based helicopter flyover
│   ├── icst_ambi_zug_langsam.lua    ← Slow train pass-by (left → right)
│   ├── icst_ambi_zug_schnell.lua    ← Fast train pass-by
│   ├── icst_ambi_zug_vergleich.lua  ← Slow vs. fast comparison on two tracks
│   ├── icst_fuma_to_ambix_foa.lua   ← Batch FuMa → AmbiX FOA channel reorder
│   ├── FuMa_to_AmbiX_FOA.jsfx      ← JSFX channel-swap plugin (FuMa → AmbiX)
│   ├── setup_icst_routing.lua       ← Auto-routes ICST AmbiEncoder → AmbiDecoder
│   ├── icst_osc_raumkurven_xyz.lua  ← OSC-driven 3D trajectory (XYZ)
│   ├── icst_stereo_pan_distanz.lua  ← Distance-based stereo panner
│   └── icst_stereo_pan_raumkurven.lua ← Spatial curve panner
│
├── 03_csound/                       ← Csound instruments (run in Cabbage)
│   ├── icst_additive_synth_osc.csd  ← Additive synth with OSC position control
│   ├── icst_ambisonics_exercise.csd ← Beginner exercise: encode → decode in Csound
│   ├── icst_cabbage_to_icst_multiencoder.csd  ← Cabbage → BlackHole → Reaper chain
│   ├── icst_hoa_spatial_synth.csd   ← HOA spatial synthesizer (3rd order)
│   ├── HOA_Synth_Demo.csd           ← Demo patch (binaural output)
│   ├── hrtf-48000-left.dat          ← HRTF dataset for binaural rendering
│   ├── hrtf-48000-right.dat
│   └── icst_cabbage_to_icst_multiencoder_setup.txt  ← BlackHole routing guide
│
├── 04_maxmsp/                       ← Max/MSP patches
│   ├── OSC-GP-ICST-MultiEncoder.maxpat  ← Gamepad → OSC → ICST MultiEncoder
│   ├── icst_hoa_generative_panner.maxpat ← Generative HOA panner (random walks)
│   └── E4L Multi-Panner_OSC.adv    ← Ableton Live device (OSC-controlled panner)
│
├── 05_act-tool/                     ← ACT-Tool (download separately — see below)
│   └── README.md
│
├── 06_python/                       ← Python utilities
│   ├── icst_audio_info.py           ← Inspect channel count / format of any audio file
│   └── icst_zylia_check.py          ← Verify Zylia ZM-1 export before Reaper import
│
└── workshop-doc/
    └── ICST_Ambisonics_Workshop.docx  ← Full workshop documentation (English)
```

---

## Quick-Start: Step by Step

### Step 1 — Install required software

| Software | Version | Link |
|---|---|---|
| Reaper | 7.x | https://www.reaper.fm |
| ICST AmbiEncoder_64 | latest | https://ambisonics.ch/learn |
| ICST AmbiDecoder | latest | https://ambisonics.ch/learn |
| Zylia App | latest | https://www.zylia.co |
| Cabbage (optional) | 2.x | https://cabbageaudio.com |
| Max/MSP (optional) | 9.x | https://cycling74.com |
| BlackHole 64ch (optional) | latest | https://existential.audio/blackhole/ |
| Python 3.9+ (optional) | latest | https://www.python.org |

Install the ICST plugins: copy `AmbiEncoder_64.vst3` and `AmbiDecoder.vst3` to your system VST3 folder, then scan in Reaper (Options → Preferences → Plug-ins → Re-scan).

---

### Step 2 — Open the Reaper Workshop Session

1. Open **`01_reaper-sessions/spatial_counterpoint_workshop.RPP`** in Reaper.
2. When prompted about missing files, point Reaper to the **`audio/`** subfolder.
3. The session opens with three mono source tracks, pre-routed through ICST AmbiEncoder_64 into a 16-channel HOA bus (3rd order AmbiX).
4. Each encoder track has an empty spatial automation lane — you will fill these during the workshop.

> **Channel format:** the session uses **AmbiX / ACN-SN3D, 3rd order (16 channels)**.  
> The decoder is set to **binaural** by default so you can follow along on headphones.

---

### Step 3 — Zylia HOA Recording (Block B)

1. Connect Zylia ZM-1 via USB.
2. Open the **Zylia App** and set the output to **19-channel A-Format WAV** (not the automatic HOA conversion).
3. Record your scene, then drag the exported WAV into Reaper.
4. Open **`01_reaper-sessions/zylia_recording_example.RPP`** to see the pre-built A→B conversion chain:
   - Track 1: 19-channel A-Format input
   - Track 2: A→B plugin (ZyliaSP or equivalent) → 16ch HOA out
5. **Check your export first** (optional):
   ```bash
   python 06_python/icst_zylia_check.py path/to/your_recording.wav
   ```

---

### Step 4 — Lua Scripts in Reaper

All scripts go into `~/Library/Application Support/REAPER/Scripts/` (macOS) or `%APPDATA%\REAPER\Scripts\` (Windows). Then load via **Actions → Load ReaScript**.

| Script | What it does |
|---|---|
| `setup_icst_routing.lua` | Automatically creates the AmbiEncoder → HOA Bus → AmbiDecoder chain |
| `icst_ambi_kopter.lua` | Writes a physics-based helicopter flyover onto the selected track |
| `icst_ambi_zug_langsam.lua` | Slow train: left → overhead → right in 30 s |
| `icst_ambi_zug_schnell.lua` | Fast train: same trajectory in 8 s |
| `icst_ambi_zug_vergleich.lua` | Runs both speeds on two separate tracks for comparison |
| `icst_fuma_to_ambix_foa.lua` | Reorders channels W/X/Y/Z → W/Y/Z/X for FuMa→AmbiX FOA |
| `icst_osc_raumkurven_xyz.lua` | Drives AmbiEncoder Azimuth/Elevation via OSC from Max or Cabbage |

**Usage example — Helicopter:**
1. Select a track that has **ICST AmbiEncoder_64** as its first FX.
2. Run `icst_ambi_kopter.lua` via Actions.
3. Play back — Azimuth, Elevation and Distance are fully automated.

---

### Step 5 — Csound / Cabbage (Block E)

Cabbage is the recommended host for the Csound patches.

1. Open Cabbage and drag in any `.csd` file from **`03_csound/`**.
2. **Additive Synth with OSC** (`icst_additive_synth_osc.csd`):
   - Generates spatial sound with position controllable via OSC port 9000.
   - Connect the Max patch `OSC-GP-ICST-MultiEncoder.maxpat` to steer it.
3. **Cabbage → Reaper via BlackHole** (`icst_cabbage_to_icst_multiencoder.csd`):
   - Cabbage synthesises audio and sends it out through **BlackHole 64ch**.
   - Reaper receives it on a 64-channel input track with ICST AmbiEncoder_64.
   - See `icst_cabbage_to_icst_multiencoder_setup.txt` for the exact routing.
4. **HRTF data**: the two `.dat` files must stay in the same folder as any `.csd` that uses `hrtfstat` or `hrtfmove2`.

---

### Step 6 — Max/MSP (Block F)

1. Open Max 9 and load a `.maxpat` from **`04_maxmsp/`**.
2. **OSC-GP-ICST-MultiEncoder** (`OSC-GP-ICST-MultiEncoder.maxpat`):
   - Connects a USB gamepad and maps its axes to azimuth / elevation.
   - Sends OSC to Reaper's ICST AmbiEncoder on port 8000.
   - In Reaper: enable OSC on port 8000 (Preferences → Control / OSC).
3. **Generative Panner** (`icst_hoa_generative_panner.maxpat`):
   - Creates random-walk trajectories for multiple virtual sources.
   - Each source sends its own OSC messages to a separate ICST AmbiEncoder channel.

---

### Step 7 — ACT-Tool (Block F — separate download)

The **ACT-Tool** is a standalone macOS application for interactive 2D/3D positioning.  
It is not included in this ZIP due to file size.

**Download:** ask your workshop instructor or check [ambisonics.ch](https://ambisonics.ch/learn).

**Installation:**
1. Unzip `ACT-Tool.zip`.
2. Move `ACT-Tool.app` to `/Applications/` or your desktop.
3. First launch: right-click → **Open** (required to bypass macOS Gatekeeper).
4. Connect via OSC to Reaper on port 8000.

---

### Step 8 — FuMa → AmbiX Conversion

If you have older FuMa material (WXYZ channel order, MaxN normalisation):

**Option A — JSFX plugin (real-time):**
1. Copy `FuMa_to_AmbiX_FOA.jsfx` to `~/Library/Application Support/REAPER/Effects/`.
2. Add it to your FOA track as an FX before the decoder.

**Option B — Lua batch script (offline):**
1. Select all FuMa tracks in Reaper.
2. Run `icst_fuma_to_ambix_foa.lua` via Actions.
3. The script inserts a channel-reorder envelope to convert W/X/Y/Z → W/Y/Z/X in-place.

---

## Python Utilities

Install the dependency once:
```bash
pip install soundfile
```

**Check any audio file:**
```bash
python 06_python/icst_audio_info.py path/to/file.wav
python 06_python/icst_audio_info.py path/to/folder/   # scans all WAV/AIFF/FLAC
```

**Verify a Zylia recording:**
```bash
python 06_python/icst_zylia_check.py path/to/zylia_recording.wav
```

---

## Ambisonics Channel Formats — Quick Reference

| Format | Channels | Order | Standard |
|---|---|---|---|
| FOA | 4 | 1st | AmbiX (ACN/SN3D) or FuMa |
| HOA 2nd | 9 | 2nd | AmbiX |
| HOA 3rd | 16 | 3rd | AmbiX (Zylia output) |
| HOA 4th | 25 | 4th | AmbiX |
| A-Format | 19 | raw | Zylia ZM-1 capsules |

**ICST AmbiEncoder_64 parameters (Param index in Reaper):**

| Index | Name | Range | Value |
|---|---|---|---|
| 10 | Azimuth | 0–1 | 0 = –180°, 0.5 = 0° (front), 1 = +180° |
| 11 | Elevation | 0–1 | 0 = –90° (below), 0.5 = 0° (horizon), 1 = +90° (above) |
| 12 | Distance | 0–1 | 0 = near, 1 = far |

---

## Troubleshooting

**ICST plugins not showing in Reaper**  
→ Preferences → Plug-ins → VST → Re-scan. Make sure the `.vst3` files are in `/Library/Audio/Plug-Ins/VST3/` (macOS system-wide).

**Zylia recording sounds wrong / phase issues**  
→ Always export A-Format (19ch) from the Zylia App. If you used the automatic HOA export, the channel order may differ from what Reaper expects.

**Lua script error: "attempt to call a nil value (field 'atan2')"**  
→ This occurs in old scripts on Reaper 7+ (Lua 5.4). Use the updated scripts in this package — they use `math.atan(y, x)` instead.

**Cabbage can't find HRTF files**  
→ Place `hrtf-48000-left.dat` and `hrtf-48000-right.dat` in the same folder as the `.csd` file.

**BlackHole 64ch not visible in Reaper**  
→ Restart your Mac after installing BlackHole. Check Audio MIDI Setup to confirm the device appears.

---

## Contact & Further Resources

- **Workshop website:** [ambisonics.ch/learn/working-with-ambisonics-workshop](https://ambisonics.ch/learn/working-with-ambisonics-workshop/)
- **ICST Ambisonics plugins:** [ambisonics.ch](https://ambisonics.ch)
- **ICST / ZHdK:** Institute for Computer Music and Sound Technology, Zurich University of the Arts

---

*ICST Ambisonics Workshop 2026 — ZHdK / ICST*  
*Package assembled May 2026*
