# ACT-Tool

The ACT-Tool is a standalone macOS application for interactive 2D/3D sound source positioning via OSC.

## Not included in this ZIP

The ACT-Tool.app is not bundled here due to file size. Please download it from your workshop instructor or at:

    https://ambisonics.ch/learn

## Installation

1. Unzip `ACT-Tool.zip`
2. Move `ACT-Tool.app` to `/Applications/` or your workshop folder
3. First launch: **right-click → Open** (macOS Gatekeeper bypass)
4. In Reaper: Preferences → Control/OSC/web → Add → OSC (UDP), port 8000
5. In ACT-Tool: set target IP to `127.0.0.1`, port `8000`

## What it does

ACT-Tool sends OSC messages to control the ICST AmbiEncoder's Azimuth, Elevation and Distance parameters in real time. You can drag sources around a 2D top-view or 3D sphere and record the movement as Reaper automation.
