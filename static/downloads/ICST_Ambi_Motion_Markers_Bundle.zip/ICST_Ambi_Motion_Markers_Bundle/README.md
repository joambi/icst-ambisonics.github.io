# ICST Ambi Motion Markers Bundle (v1.1)

Marker pairs in REAPER -> OSC motion for the ICST AmbiEncoder, or recorded automation.

## Installation

1. Copy the folder `scripts/` into your REAPER Scripts folder. Keep all three files together:
   `JS_Ambi_Motion_Marker_GUI.lua`, `JS_Import_Ambi_Markers_From_CSV.lua`, `reaper_marker_ambi_motion.py`.
2. REAPER: Actions > Show action list > New action > Load ReaScript... and load both `.lua` files.
3. Install the Python package: `python3 -m pip install python-osc`
4. Recording only: enable REAPER Preferences > Control/OSC/web > Web browser interface, port 8080.
5. AmbiEncoder: enable OSC input, port 50001 (default).

The Python field in the GUI can stay empty: the script finds a Python 3 with python-osc automatically (Homebrew, pyenv, system).
Optional toolbar icons are in `icons/`. Example CSVs are in `examples/`.
Step by step: `TUTORIAL_Motion_Markers_DE.md`, details: `ICST_Ambi_Motion_Markers_Handbook.md`.
