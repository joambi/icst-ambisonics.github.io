# Lizenz / Licence

**Deutsch:** Die Skripte, Icons und Dokumente in diesem Paket stehen unter der GNU General Public License, Version 3 oder später (GPL-3.0-or-later). Den Lizenztext finden Sie in der Datei `LICENSE`.

**English:** The scripts, icons and documents in this package are licensed under the GNU General Public License, version 3 or later (GPL-3.0-or-later). See the file `LICENSE` for the licence text.

## Nicht enthalten / Not included

- **REAPER** (Cockos Inc.) ist proprietär und nicht Teil dieses Pakets. Bezug und Lizenz: <https://www.reaper.fm> / REAPER (Cockos Inc.) is proprietary and not part of this package.
- **ICST AmbiEncoder und weitere Plugins** werden separat bezogen und behalten ihre eigene Lizenz (siehe <https://github.com/schweizerweb/icst-ambisonics-plugins>) / are obtained separately and keep their own licence.
- **js_ReaScriptAPI** (REAPER-Erweiterung, separat zu installieren) und, für Motion Markers, **Python 3 mit python-osc** (per `pip` installiert) stehen unter ihren eigenen Lizenzen / are installed separately under their own licences.

Übersicht der Drittkomponenten des vollständigen Pakets: `THIRD_PARTY_LICENSES.md` im ICST_Ambi_Reaper-Bundle.
